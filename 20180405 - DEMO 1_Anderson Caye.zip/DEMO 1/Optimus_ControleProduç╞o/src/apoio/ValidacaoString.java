/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apoio;

/**
 *
 * @author XorNOTE
 */
public class ValidacaoString {
    
    /**
     * 
     * @param trecho
     * @param tamanho
     * @return 
     */
    public static boolean vazio (String trecho, int tamanho){
        boolean result = false;
        
        if(trecho.trim().length() >= tamanho){
            result = true;
        }
        
        return result;
    }
    
}
