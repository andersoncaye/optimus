/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import apoio.Data;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JTable;
import negocio.Ferramenta;
import negocio.Fornecedor;
import persistencia.ConexaoBD;
import persistencia.IDAO_T;

/**
 *
 * @author XorNOTE
 */
public class FornecedorDao implements IDAO_T<Fornecedor> {
    
    ResultSet resultadoQ = null;

    @Override
    public String salvar(Fornecedor o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String atualizar(Fornecedor o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String excluir(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Fornecedor> consultarTodos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Fornecedor> consultar(String criterio) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Fornecedor consultarId(int id) {
        try {
            Statement st = ConexaoBD.getInstance().getConnection().createStatement();

            String sql = 
                    "SELECT * FROM fornecedor WHERE idfornecedor = " + id;

            System.out.println("sql: " + sql);

            resultadoQ = st.executeQuery(sql);

            if (resultadoQ.next()) {
                Fornecedor fornecedor = new Fornecedor();
                
                
                
                fornecedor.setIdFornecedor(id);
                fornecedor.setRazaoSocial( resultadoQ.getString("razaosocial") );
                fornecedor.setNomeFantasia( resultadoQ.getString("nomefantasia") );
                fornecedor.setCnpj( resultadoQ.getString("cnpj") );
                fornecedor.setIe( resultadoQ.getString("ie") );
                fornecedor.setEndereco( resultadoQ.getString("endereco") );
                fornecedor.setCidade( resultadoQ.getString("cidade") );
                fornecedor.setEstado( resultadoQ.getString("estado") );
                fornecedor.setAtivo( resultadoQ.getBoolean("ativo") );
                fornecedor.setDeleted( resultadoQ.getBoolean("deleted") );
                
                return fornecedor;
            }

        } catch (Exception e) {
            System.out.println("Erro ao consultar ferramenta = " + e);
        }
        return null;
    }

    @Override
    public void popularTabela(JTable tabela, String criterio, int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void popularTabelaPesquisarSimples(JTable tabela, String criterio) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
